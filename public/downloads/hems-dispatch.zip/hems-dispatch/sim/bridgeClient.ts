// Client to connect to the HEMS Bridge
console.log("Simulator bridge client placeholder");